class StorageItem {
  StorageItem(this.key, this.value);

  final String key;
  final String value;
}